<?php

class Company {
    private $CompanyKey;
    private $CompanyName;
    private $Province;
    private $Industry;
    
    function __construct($CompanyName, $Province, $Industry) {
        $this->CompanyName = $CompanyName;
        $this->Province = $Province;
        $this->Industry = $Industry;
    }

    function getCompanyKey() {
        return $this->CompanyKey;
    }

    function getCompanyName() {
        return $this->CompanyName;
    }

    function getProvince() {
        return $this->Province;
    }

    function getIndustry() {
        return $this->Industry;
    }

    function setCompanyKey($CompanyKey) {
        $this->CompanyKey = $CompanyKey;
    }

    function setCompanyName($CompanyName) {
        $this->CompanyName = $CompanyName;
    }

    function setProvince($Province) {
        $this->Province = $Province;
    }

    function setIndustry($Industry) {
        $this->Industry = $Industry;
    }


    function GetAllCompanies() {
        $connect = new Connection('clientDb');
        $rows = $connect->GetAallCompanies();
        $arrayCompanies = [];
        foreach ($rows as $row) {
            $company = new Company($row['CompanyName'], $row['Province'], $row['Industry']);
            $company->setKey($row['CompanyKey']);
            array_push($arrayCompanies, $company);
        }

        return $arrayCompanies;
    }
    
       function GetCompanyByField($CompanyField) {
        $connect = new Connection('clientDb');
        $row=$connect->GetCompanyByField($CompanyField);
        $this->setCompanyName($row[0]['CompanyName']);
        $this->setProvince($row[0]['Province']);
        $this->setIndustry($row[0]['Industry']);
        $this->setCompanyKey($row[0]['CompanyKey']);
        
return $this;
    }
    
    
    
    
     function InsertCompany(Company $company) {
        $connect = new Connection('clientDb');
        $connect->InsertCompany($this);
    }
    
    
    
    
}
