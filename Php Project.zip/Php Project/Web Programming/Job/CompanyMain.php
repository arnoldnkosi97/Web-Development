<?php 
require_once './Company.php';

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Register Page</title>
        <script src="Validation.js" type="text/javascript"></script>
        <link href="RegStyleSheet.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
         <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
        
        <header> 
        </header>
        <h2>Register</h2>
        <nav><ul>
                <li><input type="submit" value="Home" name="btnHome" /></li>
                <li><input type="submit" value="Help" name="btnHelp" /></li>
                <li><input type="submit" value="Sign In" name="btnSignIn" /></li>
           </ul></nav>
        <?php  
        
            if(isset($_POST['btnHome']))
        {   
            header('Location:main.php');
        }
        
             if(isset($_POST['btnHelp']))
        {   
            header('Location:HelpPage.php');
        }
        
             if(isset($_POST['btnSignIn']))
        {   
            header('Location:CreateAccount.php');
        }
        
        ?>
        
        <fieldset>
           
                <label>Company Name</label>
                <input id="txtComanyName" type="text" name="txtComanyName" 
                value="" 
                           onblur="ValidateInputString('txtComanyName', 'txtComanyNameError')"
                           onfocus="ValidateInputString('txtComanyName', 'txtComanyNameError')"/>
             <section id="txtComanyNameError"></section>
                <br/>
                <br/>
                <label>Province</label>
                <select name="cmbProvince">
                    <option>--Please Select option--</option>
                    <?php  $ArrayAnswer=['Mpumalanga','Gauteng','Kwazulu-Natal','Limpopo','Western-Cape','Northern-Cape','Free-State','Eastern-Cape'];
                foreach ($ArrayAnswer as $value) {
                echo "<option>$value</option>";
                 }?>
               </select>
               <br/>
               <br/>
               <label>Industry</label>
               <select name="cmbIndustry">
                    <option>--Please Select option--</option>
                <?php  $ArrayAnswer=['Admin,Office &Support','Building and Construction','Business and Management','Education','Engineering','Financial','FMCG,Retail and Wholesale','Government and Local Government','Hospitality and Restaurant','Human Resources and Recruitment','Information and Technology','Legal','Media','Medical','Mining','Motor'];
                foreach ($ArrayAnswer as $value) {
                 echo "<option>$value</option>";
                 }?>
                </select>
                <br/>
                <br/>
                <input type="submit" value="Submit" name="btnSubmit" />
                <input type="reset" value="Cancel" name="btnCancel" />
                <input type="submit" value="Help" name="btnHelp" />
           </fieldset>
        
       <?php
if (isset($_POST['btnSubmit'])) {
    $connection=new connections('clientDb');
    
    $company=new Company($_POST['txtCompanyName'], $_POST['cmnProvince'], $_POST['cmbIndustry']);
    $connection->InsertCompany($company);
    
}
?>
        <footer> 
         <h4>Follow Us</h4>
        <p>|Facebook|</p>
        <p>Instagram|</p>
        <p>Google+|</p>
        <p>WeChat|</p>
        <p>Twitter</p>
        <p>Contact Us</p>
        <p>About Us</p>
        <p>FAQ</p>
        <p>All Right Reserved</p>
        <p>T&C's</p>
        <p>&reg;</p>
        <p>&copy</p>
        
        </footer>
        </form>
     
    </body>
</html>
