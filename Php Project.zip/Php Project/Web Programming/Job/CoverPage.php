<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Cover Page</title>
        <link href="CoverStyleSheet.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form name="CoverPage" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
      
               
        <header>
            <nav><ul>
                   <li><input type="submit" value="Home" name="btnHome" /></li>
                <li><input type="submit" value="About Us" name="btnAbout" /></li>
                <li><input type="submit" value="Help" name="btnHelp" /></li>
                <li><input type="submit" value="Companies" name="btnCo" /></li>
                      
            </ul></nav>  
        </header>
         <h2>Making a cover letter!</h2>
       
         
         
         
         
         
         
          <footer>
            <h4>Follow Us</h4>
        <p>|Facebook|</p>
        <p>Instagram|</p>
        <p>Google+|</p>
        <p>WeChat|</p>
        <p>Twitter</p>
      
        <p>Contact Us</p>
        <p>About Us</p>
        <p>FAQ</p>
        <p>All Right Reserved</p>
        <p>T&C's</p>
        <p>&reg;</p>
        <p>&copy;</p>
  
        </footer>
        
      
        
        </form>
        <?php
        // put your code here
        ?>
    </body>
</html>
