<?php 
include_once './StickyHandler.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Create Account</title>
        <script src="Validation.js" type="text/javascript"></script>
        <link href="LoginStyleSheet.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form name="FrmAccount" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
        
        <header><h2>Please Login</h2></header>
        <br/>
        <br/>
        <input type="submit" value="Home" name="btnHome" />
        <br/>
        <br/>
        <fieldset>
            <legend>Login</legend>
            <br/>
            <br/>
            <label>Email address or Username</label>
            <input type="text" id="txtUsername" value="<?php StickyInput('txtUsername', 'btnLogin')?>"
                   onblur="ChangeColorByErrorString('txtUserName','txtUserNameError')"/>
            <br/>
            <br/>
            <label>Password</label>
            <input type="password" id="txtPassword" value=""/>
            <input type="submit" value="Enter" name="btnLogin" onblur="ChangeColorEmptyPassword('txtPassword','txtPasswordFocus')"/>
            <br/>
            <br/>
            <label>Dont have an account?</label>
            <input type="submit" value="Create" name="btnCreate" />
        </fieldset>
        <?php  
        
           if (isset($_POST['btnLogin'])) {
            $employee=new employee('', '','','', '', '', '', '', '','', '');
            $user = new User('', '', '');
            $check = $user->CheckLogin($_POST['txtUserName'], $_POST['txtPassword']);
            
            if ($check==true) {
                
                header('Location: CoverPage.php');
            }
            else
            {
                header('Location: Register.php');
            }
        }
        
        
        
        
        if(isset($_Post['btnCreate'])) {
            
        header('Location:EmployeeMain.php');
        } 
           if(isset($_POST['btnHome']))
        {   
            header('Location:main.php');
        }
        
        ?>
        <br/>
        <br/>
        <br/>
      
        <footer>
          
        <h4>Follow us</h4>
        <p>|Facebook|</p>
        <p>Instagram|</p>
        <p>Google+|</p>
        <p>WeChat|</p>
        <p>Twitter</p>
        <br/>
        <p>Contact Us</p>
        <p>About Us</p>
        <p>FAQ</p>
        <p>All Right Reserved</p>
        <p>T&C's</p>
        <p>&reg;</p>
        <p>&copy;</p>
        
        </footer>
        </form>
        <?php
   
        if(isset($_Post['btnSubmit']))
        {
            $Username=$_Post['txtUserName'];
            
            
            
            
        }
        
        
        
        
        ?>
    </body>
</html>
