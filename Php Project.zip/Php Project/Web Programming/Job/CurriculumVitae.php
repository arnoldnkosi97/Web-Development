<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link href="LoginStyleSheet.css" rel="stylesheet" type="text/css"/>
        <title></title>
    </head>
    <body>
        <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
        <header>
            <nav><ul>
                   <li><input type="submit" value="Home" name="btnHome" /></li>
               
                <li><input type="submit" value="Help" name="btnHelp" /></li>
                <li><input type="submit" value="Companies" name="btnCo" /></li>
                      
                  <?php  
        
            if(isset($_POST['btnHome']))
        {   
            header('Location:main.php');
        }
        
             if(isset($_POST['btnHelp']))
        {   
            header('Location:HelpPage.php');
        }
        
             if(isset($_POST['btnSignIn']))
        {   
            header('Location:CreateAccount.php');
        }
        ?>
            </ul></nav>  
        </header>
            
            
            <h2>Making a Curriculum Vitae!</h2>
         <fieldset><ol>
             <li><h3>Personal Details</h3></li>
             <br/>
             <br/>
             <li>First Name</li>
             <input type="text" name="txtFname" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtFname';} ?>" />
            
             <br/>
             <br/>
             <li>Middle name</li>
             <input type="text" name="txtMname" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtMname';} ?>" />
             
             <br/>
             <br/>
             <li>Surname</li>
             <input type="text" name="txtSname" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtSname';} ?>" />
            
             <br/>
             <br/>
             <li>Location</li>
             <input type="text" name="txtlocation" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtlocation';} ?>" />
             
             <br/>
             <br/>
             <li>Nationality</li>
             <input type="text" name="txtnationality" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtnationality';} ?>" />
      
             <br/>
             <br/>
             <li>Email address</li>
             <input type="text" name="txtEmail" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtEmail';} ?>" />
            
             <br/>
             <br/>
             <li>Availability</li>
             <input type="text" name="txtAvailability" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtAvailability';} ?>" />
            
             <br/>
             <br/>
             <li>Current Salary</li>
             <input type="text" name="txtCurrentSalary" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtCurrentSalary';} ?>" />
           
             <br/>
             <br/>
             <li>Salary Expectations</li>
             <input type="text" name="txtExpectedSalary" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtExpectedSalary';} ?>" />
            
             <br/>
             <br/>
             <h3>Educational Background</h3>
             <br/>
             <br/>
             <li>Qualifications</li>
             <input type="text" name="txtQualification" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtQualification';} ?>" />
             <input type="text" name="txtSecondQualification" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtSecondQualification';} ?>" />
             <input type="text" name="txtThirdQualification" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtThirdQualification';} ?>" />
           <br/>
             <br/>
             <li>institution</li>
             <input type="text" name="txtInstitution" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtInstitution';} ?>" />
             <br/>
             <br/>
             <li>Year And Month Completed</li>
     =
             <input type="text" name="txtYear" value="<?php if(isset($_POST['btnSubmit'])){ echo 'txtYear';} ?>" />
             <select name="cmbMonth">
                 <option>--Please Select Month--</option>
                 <?php  $ArrayMonth=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sept','Oct','Nov','Dec'];
  foreach ($ArrayMonth as $value) {
     
  
                     echo "<option>$value</option>";
  }
                 ?>
             </select>
            <br/>
             <br/>
             <li>Courses Taken</li>
             <input type="text" name="txtCourse" value="" />
             <input type="text" name="txtSecondCourse" value="" />
             <input type="text" name="txtThirdCourse" value="" />
             <input type="text" name="txtFourthCourse" value="" />
             <input type="text" name="txtFifthCourse" value="" />
             <br/>
             <br/>
             <h3>Employment History</h3>
             <br/>
             <br/>
             <li>Job Title</li>
             <input type="text" name="txtJobTitle" value="" />
             <br/>
             <br/>
             <li>Name of Employer</li>
             <input type="text" name="txtEmployerName" value="" />
             <br/>
             <br/>
             <li>Period of Employment</li>
            <input type="text" name="txtEmployedPeriod" value="" />
            <br/>
             <br/>
             <li>Salary Paid</li>
             <input type="text" name="txtJobSalary" value="" />
             <br/>
             <br/>
             <li>Duties</li>
             <input type="text" name="txtDuties" value="" />
             <br/>
             <br/>
             
             <input type="submit" value="Submit" name="btnSubmit" />
             </ol></fieldset>
            
            
            
            
        </form>
        
        
        <?php
        if(isset($_POST['btnSubmit']))
        {
        $FirstName=$_POST['txtFname'];
        $middlename=$_POST['txtMname'];
        $Surname=$_POST['txtSname'];
        $location=$_POST['txtlocation'];
        $Nationality=$_POST['txtnationality'];
        $email=$_POST['txtEmail'];
        $Availablity=$_POST['txtAvailability'];
        $qualifications=($_POST['txtQualification'])+""+($_POST['txtSecondQualification'])+""+($_POST['txtThirdQualification']);
        $curentSalary=$_POST['txtCurrentSalary'];
        $expectedSalary=$_POST['txtExpectedSalary'];
        
        $institution=$_POST['txtInstitution'];
        $yearCompleted=($_POST['cmbMonth'])+""+($_POST['txtYear']);
        $course=($_POST['txtCourse'])+""+($_POST['txtSecondCourse'])+""+($_POST['txtThirdCourse'])+""+($_POST['txtFourthCourse'])+""+($_POST['txtFifthCourse']);
        $jobTitle=$_POST['txtJobTitle'];
        $employerName=$_POST['txtEmployerName'];
        $periodEmployed=$_POST['txtEmployed'];
        $salaryPaid=$_POST['txtJobSalary'];
        $duties=$_POST['txtDuties'];
        
        $newCv= new Cv($FirstName, $middlename, $Surname, $location, $nationality, $email, $availability, $curentSalary, $expectedSalary,
        $qualifications, $institution, $yearCompleted,
        $course, $jobTitle, $employerName, $periodEmployed, $salaryPaid, $duties);
        $connect=new connections('clientDb');
        $connect->InsertCv($newCv);
        
        
        
        }
        ?>
    </body>
</html>
