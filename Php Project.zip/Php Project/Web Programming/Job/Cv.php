<?php
require_once './Connection.php';
class Cv {
    private $EmployerForeignKey;
    private $FirstName;
    private $middlename;
    private $Surname;
    private $location;
    private $nationality;
    private $email;
    private $availability;
    private $curentSalary;
    private $expectedSalary;
    private $qualifications;
    private $institution;
    private $yearCompleted;
    private $course;
    private $jobTitle;
    private $employerName;
    private $periodEmployed;
    private $salaryPaid;
    private $duties;
    
    function __construct($FirstName, $middlename, $Surname, $location, $nationality, $email, $availability, $curentSalary, $expectedSalary, $qualifications, $institution, $yearCompleted, $course, $jobTitle, $employerName, $periodEmployed, $salaryPaid, $duties) {
        $this->FirstName = $FirstName;
        $this->middlename = $middlename;
        $this->Surname = $Surname;
        $this->location = $location;
        $this->nationality = $nationality;
        $this->email = $email;
        $this->availability = $availability;
        $this->curentSalary = $curentSalary;
        $this->expectedSalary = $expectedSalary;
        $this->qualifications = $qualifications;
        $this->institution = $institution;
        $this->yearCompleted = $yearCompleted;
        $this->course = $course;
        $this->jobTitle = $jobTitle;
        $this->employerName = $employerName;
        $this->periodEmployed = $periodEmployed;
        $this->salaryPaid = $salaryPaid;
        $this->duties = $duties;
    }
    function getEmployerForeignKey() {
        return $this->EmployerForeignKey;
    }

    function getFirstName() {
        return $this->FirstName;
    }

    function getMiddlename() {
        return $this->middlename;
    }

    function getSurname() {
        return $this->Surname;
    }

    function getLocation() {
        return $this->location;
    }

    function getNationality() {
        return $this->nationality;
    }

    function getEmail() {
        return $this->email;
    }

    function getAvailability() {
        return $this->availability;
    }

    function getCurentSalary() {
        return $this->curentSalary;
    }

    function getExpectedSalary() {
        return $this->expectedSalary;
    }

    function getQualifications() {
        return $this->qualifications;
    }

    function getInstitution() {
        return $this->institution;
    }

    function getYearCompleted() {
        return $this->yearCompleted;
    }

    function getCourse() {
        return $this->course;
    }

    function getJobTitle() {
        return $this->jobTitle;
    }

    function getEmployerName() {
        return $this->employerName;
    }

    function getPeriodEmployed() {
        return $this->periodEmployed;
    }

    function getSalaryPaid() {
        return $this->salaryPaid;
    }

    function getDuties() {
        return $this->duties;
    }

    function setEmployerForeignKey($EmployerForeignKey) {
        $this->EmployerForeignKey = $EmployerForeignKey;
    }

    function setFirstName($FirstName) {
        $this->FirstName = $FirstName;
    }

    function setMiddlename($middlename) {
        $this->middlename = $middlename;
    }

    function setSurname($Surname) {
        $this->Surname = $Surname;
    }

    function setLocation($location) {
        $this->location = $location;
    }

    function setNationality($nationality) {
        $this->nationality = $nationality;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setAvailability($availability) {
        $this->availability = $availability;
    }

    function setCurentSalary($curentSalary) {
        $this->curentSalary = $curentSalary;
    }

    function setExpectedSalary($expectedSalary) {
        $this->expectedSalary = $expectedSalary;
    }

    function setQualifications($qualifications) {
        $this->qualifications = $qualifications;
    }

    function setInstitution($institution) {
        $this->institution = $institution;
    }

    function setYearCompleted($yearCompleted) {
        $this->yearCompleted = $yearCompleted;
    }

    function setCourse($course) {
        $this->course = $course;
    }

    function setJobTitle($jobTitle) {
        $this->jobTitle = $jobTitle;
    }

    function setEmployerName($employerName) {
        $this->employerName = $employerName;
    }

    function setPeriodEmployed($periodEmployed) {
        $this->periodEmployed = $periodEmployed;
    }

    function setSalaryPaid($salaryPaid) {
        $this->salaryPaid = $salaryPaid;
    }

    function setDuties($duties) {
        $this->duties = $duties;
    }

    
    function InsertCv()
{
    $connect=new connections('clientDb');
$connect->connectDb();
$connect->InsertCv($this);


}
}
