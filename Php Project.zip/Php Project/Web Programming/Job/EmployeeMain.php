<?php 
include_once './StickyHandler.php'; 
 require_once './FileHandler.php';
 require_once './EmployeeMain.php';


?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Register Page</title>
        <script src="Validation.js" type="text/javascript"></script>
        <link href="RegStyleSheet.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
 <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
        
        <header> 
        </header>
        <h2>Register</h2>
        <nav><ul>
                <li><input type="submit" value="Home" name="btnHome" /></li>
                <li><input type="submit" value="Help" name="btnHelp" /></li>
                <li><input type="submit" value="Sign In" name="btnSignIn" /></li>
                <li><input type="submit" value="Create Cv" name="btnCv" /></li>
           </ul></nav>
        <?php  
        
            if(isset($_POST['btnHome']))
        {   
            header('Location:main.php');
        }
        
             if(isset($_POST['btnHelp']))
        {   
            header('Location:HelpPage.php');
        }
        
             if(isset($_POST['btnSignIn']))
        {   
            header('Location:CreateAccount.php');
        }
        if(isset($_POST['btnCv']))
        {
            header('Location:CurriculumVitae.php');
        }
        
        ?>
        
        <fieldset>
            <legend>Personal Information</legend>
            <p>  
                <label>Title:</label>
                <select name="Title">
                    <option>--Please Select Title--</option>
                    <?php  
                    $ArrayTitle=['Ms','Mr','Dr','Prof'];
                    foreach ($ArrayTitle as $title)
                    {
                        StickyDropDown('Title', $arrayTitle, 'btnSubmit');
                                
                         echo "<option>$title</option>";
                    }
                    ?>
                </select>
                <br/>
                <br/>
                <label>First Name</label>
                <input id="txtName" type="text" name="txtname" 
                value="<?php StickyInput('txtname', 'btnSubmit') ?>" 
                           onblur="ValidateInputString('txtName', 'txtNameInputError')"
                           onfocus="ValidateInputString('txtName', 'txtNameInputError')"/>
             <section id="txtNameInputError"></section>
                
              <label>Surname</label>
              <input type="text" id="txtSurname" 
               value="<?php StickyInput('txtSurname', 'btnSubmit') ?>" 
                           onblur="ValidateInputString('txtSurname', 'txtNameInput')"
                           onfocus="ValidateInputString('txtSurname', 'txtNameInput')"/>
             <section id="txtNameInput"></section>
                <br/>
                <br/>
                <label>Date of Birth</label>
                <input type=text id="txtDoB" value="<?php StickyInput('txtDoB','btnSubmit')?>"
                onblur="ValidateInputNumber('txtDoB', 'txtNameInputDb')"
                onfocus="ValidateInputNumber('txtDoB', 'txtNameInputDb')"/>
                <section id="txtNameInput"></section>
                <br/>
                <br/>
                <label>Are you a South African citizen</label>
                <br/>
                <br/>
                <select name="cmbNationality">
                    <option>--Please Select option--</option>
                    <?php  $ArrayAnswer=['Yes','No'];
                    
  foreach ($ArrayAnswer as $value) {
    
      echo "<option>$value</option>";
  }?>
             </select>
            <br/>
            <br/>
                <label>Enter your ID or Passport Number:</label>
                <input type="text" id="txtId" value="<?php StickyInput('ID', 'btnSubmit')?>"
                onblur="ValidateInputNumber('txtId, 'txtIDError')"
                onfocus="ValidateInputNumber('txtId', 'txtIDError')"/>
                <section id="txtIDError"></section>
                <br/>
                <br/>
                <label>Gender</label>
                <br/><select name="cmbGender">
                    <option>--Please Choose Option--</option>
                    <?php    
                    $ArrayGender=['Male','Female'];
                    
                    foreach ($ArrayGender as $value) {
                        
                          echo "<option>$value</option>";
                    }
                    ?>
                    
                </select>
                <br/>
                 <br/>
                <label>Address:</label><br/>
                <textarea id="txtAddress" rows="3" cols="80"></textarea>
                <br/>
                <label>Upload Cv</label>
                <input type="file" id="CV" value="pdf file"  onblur=""/>
                <br/>
                <br/>
                <label>Upload ID Document</label>
                <input type="file" id="idDocument" value="pdf file" onblur="" />
                <br/>
                <br/>
           <label>Preferred Field</label>
            <input id="txtField" type="text" name="txtField" 
                value="<?php StickyInput('txtField', 'btnSubmit') ?>" 
                           onblur="ValidateEmpty('txtField', 'txtFieldInputError')"
                           onfocus="ValidateEmpty('txtField', 'txtFieldInputError')"/>
             <section id="txtNameInputError"></section>
           <br/>
           <br/>
           <input type="submit" value="Submit" name="btnSubmit" />
           <input type="reset" value="Cancel" name="btnCancel" />
           <input type="submit" value="Help" name="btnHelp" />
           
        </fieldset>
        
       <?php
if (isset($_POST['btnSubmit'])) {
    
   /* $connection = new connections('clientDb');
    $employee= new employee($_POST['Title'],$_POST['txtName'],$_POST['txtSurname'], $_POST['txtDoB'], $_POST['SACitizen'], $_POST['txtId'],$_POST['cmbGender'] , $_POST['txtAddress'],$_POST['txtField']);
    $employee = clone UploadCv('btnSubmit', 'CV', $employee);
    $employee = clone UploadId('btnSubmit', 'idDocument', $employee);
    $connection->InsertEmployee($employee);*/
  }

?>
        <footer> 
         <h4>Follow Us</h4>
        <p>|Facebook|</p>
        <p>Instagram|</p>
        <p>Google+|</p>
        <p>WeChat|</p>
        <p>Twitter</p>
        <p>Contact Us</p>
        <p>About Us</p>
        <p>FAQ</p>
        <p>All Right Reserved</p>
        <p>T&C's</p>
        <p>&reg;</p>
        <p>&copy</p>
        
        </footer>
        </form>
     
    </body>
</html>
