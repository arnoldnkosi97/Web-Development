<?php
require_once './employee.php';

function UploadCv($button,$file, employee $employee){
    if (isset($_POST[$button])) {
       $File = $_FILES[$file];
       
       $FileName = $File['name'];
       $FileSize = $File['size'];
       $FileLocation = $File['tmp_name'];
       $FileError = $File['error'];
       
       $FileExt = explode(".", $FileName);
       $FileExt = strtolower(end($FileExt));
       $FileDest = "Uploads//".$FileName;
       $allowedExt = ["jpeg","jpg","png"];
       
       if (in_array($FileExt, $allowedExt)) {
           if ($FileSize < ((1024*1024)*5)) {
               if ($FileError===0) {
                   if (move_uploaded_file($FileLocation, $FileDest)) {
                       $employee->setCv($FileDest);
                       return $employee;
                   }else{
                       echo "cannot upload file";
                   }
               }else{
                   echo "Critical Error";
               }
           }else{
               echo "File Size exceeded 5MB";
           }
       }else{
           echo "File Exstension not allowed";
       }
    }
}


function UploadId($button,$file,  employee $employee){
    if (isset($_POST[$button])) {
       $File = $_FILES[$file];
       
       $FileName = $File['name'];
       $FileSize = $File['size'];
       $FileLocation = $File['tmp_name'];
       $FileError = $File['error'];
       
       $FileExt = explode(".", $FileName);
       $FileExt = strtolower(end($FileExt));
       $FileDest = "Uploads//".$FileName;
       $allowedExt = ["jpeg","jpg","png"];
       
       if (in_array($FileExt, $allowedExt)) {
           if ($FileSize < ((1024*1024)*5)) {
               if ($FileError===0) {
                   if (move_uploaded_file($FileLocation, $FileDest)) {
                       $employee->setId($FileDest);
                       return $employee;
                   }else{
                       echo "cannot upload file";
                   }
               }else{
                   echo "Critical Error";
               }
           }else{
               echo "File Size exceeded 5MB";
           }
       }else{
           echo "File Exstension not allowed";
       }
    }
}