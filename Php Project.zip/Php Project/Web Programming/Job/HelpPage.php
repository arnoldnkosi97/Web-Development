<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Help</title>
        <link href="HelpStyleSheet.css" rel="stylesheet" type="text/css"/>
    </head>
    <body><form name="FrmHelp" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
       
             
        <header>
            <h2>We are here to help you!
            </h2>
                <nav><ul>
                <li><input type="submit" value="Home" name="btnHome" /></li>
              
                <li><input type="submit" value="Register" name="btnRegister" /></li>
                <li><input type="submit" value="Companies" name="btnCompanies" /></li>
                
            </ul></nav>
             
              
        </header>
        <fieldset>
            <legend>Report</legend>
            <p>Please fill in.</p>
            <br/>
            <label>Enter help</label><br/>
            <textarea id="Preport"  rows="5" cols="65"  ></textarea>
        </fieldset>
        <br/>
      <footer>
            <h4>Follow Us</h4>
        <p>|Facebook|</p>
        <p>Instagram|</p>
        <p>Google+|</p>
        <p>WeChat|</p>
        <p>Twitter</p>
      
        <p>Contact Us</p>
        <p>About Us</p>
        <p>FAQ</p>
        <p>All Right Reserved</p>
        <p>T&C's</p>
        <p>&reg;</p>
        <p>&copy;</p>
        
        
        </footer>
        </form>
        <?php
        
          if(isset($_POST['btnHome']))
        {   
            header('Location:main.php');
        }
        
           if(isset($_POST['btnRegister']))
        {   
            header('Location:CreateAccount.php');
        }
        if(isset($_POST['btnCompanies'])){
            header('Location: ShowAllCompanies.php');
        }
        ?>
    </body>
</html>
