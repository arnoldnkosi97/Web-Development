<?php


class LoginClass {
 
    private $username;
    private $password;
    
    function __construct($username, $password) {
        $this->username = $username;
        $this->password = $password;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getPassword() {
        return $this->password;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

function GetUserByName($username)
{
    $connect=new connection('client');
    $rows=$connect->GetUserByName($username);
    $ArrayUser=[];
    foreach ($rows as $row) {
        
        $user=new LoginClass('','');
        $user->setUsername($row['Username']);
        $user->setUsername($row['Password']);
        array_pad($ArrayUser,$user);
}
return $ArrayUser;

    }

    
    
    
    
}
