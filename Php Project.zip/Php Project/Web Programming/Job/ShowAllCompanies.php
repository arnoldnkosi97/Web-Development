<?php 

require_once './FileHandler.php';
require_once './Company.php';



?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="RegStyleSheet.css" rel="stylesheet" type="text/css"/>
        <title></title>
    </head>
    <body>
        <ol>
            <label>Search</label>
         
               <select name="cmbIndustry">
                    <option>--Please Select option--</option>
                <?php  $ArrayAnswer=['Admin,Office &Support','Building and Construction','Business and Management','Education','Engineering','Financial','FMCG,Retail and Wholesale','Government and Local Government','Hospitality and Restaurant','Human Resources and Recruitment','Information and Technology','Legal','Media','Medical','Mining','Motor'];
                foreach ($ArrayAnswer as $value) {
                 echo "<option>$value</option>";
                 }?>
                </select>
         <input type="submit" value="Search" name="btnSearch" /></li>
         <li><input type="submit" value="Show All" name="btnAll" /></li>
      
           
            
        </ol>
        <?php
        
        $company= new Company('', '', '');
        $companyList=$company->GetAllCompanies();
       //If All Companies must be shown...
        if(isset($_POST['btnAll']))
        {
      foreach ($companyList as $companies){
      
                      echo '<fieldset><ol>
<li> ".$companies->getCompanyName()."</li>
<li> ".$companies->getProvince()."</li>
<li> ".$companies->getIndustry()."</li>
</ol></fieldset>
';
      }
        
        }
      
        //If Field Searched...
        if(isset($_POST['btnSearch']))
        {
        $Search=new Company($_POST['cmbIndustry'],'', '');
        $connection= new connections('clientDb');
        $ArraySearchedCompanies=$connection->GetCompanyByField($Search);
        }
        
        
        
        
        ?>
    </body>
</html>
