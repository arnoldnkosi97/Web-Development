<?php

function StickyInput($input,$button)
{
    if(isset($_POST[$button]))
    {
        echo $_POST[$input];
    }
}

function StickyDropDown($input,$array,$button)
{
    foreach ($array as $value) {
        
        if(isset($_POST[$button]))
        {
            if($_POST[$input]==$value)
            {
            echo "<option selected>$value</option>";
        }
        else
            {
            
            echo "<option>$value</option>";
        }
    }else
            {
            echo "<option>$value</option>";
        }
    
    }
}

function StickyRadio($input,$value)
{
    if($_POST[$input]==$value)
    {
        echo "CHECKED";
    }
}