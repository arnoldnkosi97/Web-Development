function CheckEmpty(id){
    element = document.getElementById(id);
    
    if (element.value == "") {
        
        return false;
    }
    return true;
}

function CheckStringOnly(id){
    element = document.getElementById(id);
    expression = /^[A-Za-z]+$/;
    if (element.value.match(expression)) {
        return true;
    }
    return false;
}

function CheckNumberOnly(id){
    element = document.getElementById(id);
    expression = /^[0-9]+$/;
    if (element.value.match(expression)) {
        return true;
    }
    return false;
}

function ValidateInputString(inputId,errorId){
    elementInput = document.getElementById(inputId);
    elementError = document.getElementById(errorId);
    
    if (CheckEmpty(inputId)) {
        elementInput.style = "border: red thick solid";
        elementError.style = "color: red";
        elementError.innerHTML = "Field cannot be empty";
    }else{
        elementInput.style = "border: green thick solid";
        elementError.innerHTML = "";
    }
    
    if (CheckStringOnly(inputId)) {
        elementInput.style = "border: red thick solid";
        elementError.style = "color: red";
        //elementError.innerHTML = "Field cannot contain numbers";
    }else{
        elementInput.style = "border: green thick solid";
        elementError.innerHTML = "";
    }
}


function  ValidateNumber(inputId,errorId){
    elementInput = document.getElementById(inputId);
    elementError = document.getElementById(errorId);
    
    if (CheckEmpty(inputId)) {
        elementInput.style = "border: red thick solid";
        elementError.style = "color: red";
        elementError.innerHTML = "Field cannot be empty";
    }else{
        elementInput.style = "border: green thick solid";
        elementError.innerHTML = "";
    }
    
    if (CheckStringOnly(inputId)) {
        elementInput.style = "border: red thick solid";
        elementError.style = "color: red";
        elementError.innerHTML = "Field cannot contain numbers";
    }else{
        elementInput.style = "border: green thick solid";
        elementError.innerHTML = "";
    }
}

function ValidateEmpty(inputId,errorId){
    elementInput = document.getElementById(inputId);
    elementError = document.getElementById(errorId);
    
    if (!CheckEmpty(inputId)) {
        elementInput.style = "border: red thick solid";
        elementError.style = "color: red";
        elementError.innerHTML = "Field cannot be empty";
    }else{
        elementInput.style = "border: green thick solid";
        elementError.innerHTML = "";
    }
    
    
   
}