-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2017 at 01:31 PM
-- Server version: 5.7.11
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `client`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `PrimaryKey` int(11) NOT NULL,
  `Title` varchar(5) NOT NULL,
  `FirstName` varchar(15) NOT NULL,
  `MiddleName` varchar(15) NOT NULL,
  `Surname` varchar(15) NOT NULL,
  `Province` varchar(20) NOT NULL,
  `EmailAddress` varchar(20) NOT NULL,
  `ContactNumber` int(10) NOT NULL,
  `IDNumber` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employeecv`
--

CREATE TABLE `employeecv` (
  `PrimaryKey` int(11) NOT NULL,
  `FirstName` varchar(15) NOT NULL,
  `MiddleName` varchar(15) NOT NULL,
  `Surname` varchar(15) NOT NULL,
  `Location` varchar(20) NOT NULL,
  `Nationality` varchar(20) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Gender` text NOT NULL,
  `ContactNumber` int(10) NOT NULL,
  `EmailAddress` varchar(20) NOT NULL,
  `Availability` text NOT NULL,
  `CurrentSalary` decimal(10,0) NOT NULL,
  `SalaryExpectations` decimal(10,0) NOT NULL,
  `Qualification` varchar(50) NOT NULL,
  `Institution` varchar(20) NOT NULL,
  `YearMonthCompleted` date NOT NULL,
  `Course` varchar(20) NOT NULL,
  `JobTitle` varchar(15) NOT NULL,
  `EmployerName` varchar(15) NOT NULL,
  `WorkPeriod` text NOT NULL,
  `Salary` decimal(10,0) NOT NULL,
  `Duties` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `PrimaryKey` int(11) NOT NULL,
  `CompanyName` varchar(20) NOT NULL,
  `Address` text NOT NULL,
  `Industry` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifying`
--

CREATE TABLE `notifying` (
  `EmailAddress` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`PrimaryKey`),
  ADD UNIQUE KEY `EmployeeID` (`IDNumber`);

--
-- Indexes for table `employeecv`
--
ALTER TABLE `employeecv`
  ADD PRIMARY KEY (`PrimaryKey`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`PrimaryKey`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `PrimaryKey` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employeecv`
--
ALTER TABLE `employeecv`
  MODIFY `PrimaryKey` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `PrimaryKey` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
