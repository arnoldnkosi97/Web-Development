
<?php
require_once './employee.php';
require_once './Company.php';

class connections {
    
    private $database;
    private $host;
    private $username;
    private $password;
    private $link;
    
    
    function __construct($database="clientDb", $host="localhost", $username="root", $password="") {
        $this->database = $database;
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->connectDb();
    }
    function connectDb()
    {
        $this->link=new mysqli($this->host, $this->username, $this->password, $this->database);
    }
    
   
    
    public function getDatabase() {
        return $this->database;
    }

    public function getHost() {
        return $this->host;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getLink() {
        return $this->link;
    }

    public function setDatabase($database) {
        $this->database = $database;
    }

    public function setHost($host) {
        $this->host = $host;
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    public function setLink($link) {
        $this->link = $link;
    }
    
    /////////////////////////////////////////////////////////////////////////
    //
    //Insert New Employee.......
    
    function InsertEmployee(employee $employee)
    {
        $query="INSERT INTO `employee`(`EmployeeKey`, `FirstName`, `Surname`, `Nationality`, `Gender`, `Address`, `IdNumber`, `Cv`, `Id`, `PreferredField`) 
                VALUES (null,$employee->getTitle(),$employee->getFirstName(),$employee->getSurname(),$employee->getNationality(),
                        $employee->getGender(),$employee->getAddressAddress(),$employee->getIdNumber(),$employee->getCv(),$employee->getId(),$employee->getField())";
         mysqli_query($this->link, $query);
}


  function GetEmployeeByName($username){
        $qeury = "SELECT * FROM `employee` WHERE `FirstName`='$username'";
        $result = mysqli_query($this->link, $qeury);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        
        return $rows;
    }
  
  function GetAllEmployees(){
        $qeury = "SELECT * FROM `employee`";
        $result = mysqli_query($this->link, $qeury);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        
        return $rows;
    }

//////////////////////////////////////////////////////////////////////////////////

  //Get All Companies to be displayed...  
     function GetAllCompanies(){
        $query = "SELECT * FROM `company`";
        $result = mysqli_query($this->link, $query);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        
        return $rows;
    }
    
    
    //Get All Companies to be displayed by using field as filter......
    
    function GetCompanyByField($CompanyField){
        $qeury = "SELECT * FROM `company` WHERE `CompanyName`='$CompanyField'";
        $result = mysqli_query($this->link, $qeury);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        
        return $rows;
    }

    
    function InsertCompany(Company $company)
    {
        $query="INSERT INTO `company`(`CompanyKey`, `CompanyName`, `Province`, `Industry`) VALUES (null,$company->getCompanyName(),$company->getProvince(),$company->getIndustry())";
         mysqli_query($this->link, $query);
}

function InsertCv(Cv $cVitae)
{
    $query="INSERT INTO `Cv`(`EmployeeForeignKey`, `FirstName`, `MiddleName`, `Surname`, `Location`, `Nationality`, `EmailAddress`, `Availability`, `CurrentSalary`, `ExpectedSalary`, `Qualifications`, `Institution`, `YearMonthCompleted`, `Courses`, `JobTitle`, `NameEmployer`, `PeriodEmployed`, `SalaryPaid`, `Duties`)
            VALUES (null,$cVitae->getFirstName(),$cVitae->getMiddlename(),$cVitae->getSurname(),$cVitae->getLocation(),$cVitae->getNationality(),$cVitae->getEmail(),$cVitae->getAvailability(),$cVitae->getCurentSalary(),$cVitae->getExpectedSalary(),$cVitae->getQualifications(),$cVitae->getInstitution(),$cVitae->getYearCompleted(),$cVitae->getCourse(),$cVitae->getJobTitle(),$cVitae->getEmployerName(),$cVitae->getPeriodEmployed(),$cVitae->getSalaryPaid(),$cVitae->getDuties())";
    mysqli_query($this->link, $query);
}

}
