<?php
require_once './connections.php';
class employee {
    
    private $PersonKey;
    private $title;
    private $FirstName;
    private $Surname;
    private $DatOfBirth;
    private $Nationality;
    private $idNumber;
    private $gender;
    private $address;
    private $Cv;
    private $id;
    private $Field;
    
    function __construct($title, $FirstName, $Surname, $DatOfBirth, $Nationality, $idNumber, $gender, $address, $Cv, $id, $Field) {
        $this->title = $title;
        $this->FirstName = $FirstName;
        $this->Surname = $Surname;
        $this->DatOfBirth = $DatOfBirth;
        $this->Nationality = $Nationality;
        $this->idNumber = $idNumber;
        $this->gender = $gender;
        $this->address = $address;
        $this->Cv = $Cv;
        $this->id = $id;
        $this->Field = $Field;
    }
    function getPersonKey() {
        return $this->PersonKey;
    }

    function getTitle() {
        return $this->title;
    }

    function getFirstName() {
        return $this->FirstName;
    }

    function getSurname() {
        return $this->Surname;
    }

    function getDatOfBirth() {
        return $this->DatOfBirth;
    }

    function getNationality() {
        return $this->Nationality;
    }

    function getIdNumber() {
        return $this->idNumber;
    }

    function getGender() {
        return $this->gender;
    }

    function getAddress() {
        return $this->address;
    }

    function getCv() {
        return $this->Cv;
    }

    function getId() {
        return $this->id;
    }

    function getField() {
        return $this->Field;
    }

    function setPersonKey($PersonKey) {
        $this->PersonKey = $PersonKey;
    }

    function setTitle($title) {
        $this->title = $title;
    }

    function setFirstName($FirstName) {
        $this->FirstName = $FirstName;
    }

    function setSurname($Surname) {
        $this->Surname = $Surname;
    }

    function setDatOfBirth($DatOfBirth) {
        $this->DatOfBirth = $DatOfBirth;
    }

    function setNationality($Nationality) {
        $this->Nationality = $Nationality;
    }

    function setIdNumber($idNumber) {
        $this->idNumber = $idNumber;
    }

    function setGender($gender) {
        $this->gender = $gender;
    }

    function setAddress($address) {
        $this->address = $address;
    }

    function setCv($Cv) {
        $this->Cv = $Cv;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setField($Field) {
        $this->Field = $Field;
    }

  
    //Insert New Employee.......
        
    function InsertEmployee(employee $employee) {
        $connect = new Connection('clientDb');
        $connect->InsertEmployee($this);
    }

    /*
    function GetAllEmployees() {
        $connect = new Connection('clientDb');
        $rows=$connect->GetAllCompanies();
        $arrayEmployees = [];
        foreach ($rows as $row) {
            $employee=new employee($row['Title'],$row['FirstName'], $row['Surname'], $row['DatOfBirth'], $row['Nationality'], $row['idNumber'], $row['gender'], $row['address'], $row['Cv'], $row['id'], $row['Field']);
            $employee->setKey($row['EmployeeKey']);
            array_push($arrayEmployees, $employee);
        }

        return $arrayEmployees;
    }
*/
    
    
    
   /*  function CheckLogin($username,$password)
    {
        $connection = new Connection("logindb","root","");
        $rows = $connection->getAllUsersByName($username);
        
        $check = false;
        foreach ($rows as $row) {
            if ($row['UserPassword']==$password) {
                $check = true;
                $_SESSION['UserID'] = $row['UserID'];
            }
        }
        
        return $check;
    }*/
}

    
 


    
    
    
    
    

