
<html>
    <head>
        <meta charset="UTF-8">
        <title>Welcome</title>
        <link href="StyleSheet.css" rel="stylesheet" type="text/css"/>
    </head>
    <body><form name="FrmMain" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
    
        
        <header><h2>Welcome to FindAjob.co.za</h2>
            <h7>Let's Find you a Job!</h7>
        </header>
             <nav><ul>
                <li><input type="submit" value="Home" name="btnHome" /></li>
                <li><input type="submit" value="About Us" name="btnAbout" /></li>
                <li><input type="submit" value="Help" name="btnHelp" /></li>
                <li><input type="submit" value="Companies" name="btnCompanies" /></li>
            </ul></nav>
             
            <article>  
                <br>
                <br>
            <ol>
               <li><input type="submit" value="Client" name="btnClient" /></li>
                <li><input type="submit" value="Company" name="btnCompany" /></li>
            </ol>
            </article>
        <br/>
        <br/>
       <h5>Jobs are currently available in these industries:</h5>
        
        <aside><pre>
               . Engineering and Construction
               . Finance
               . Hospitality
               . Office
               . Technology
            </pre>
        </aside>
        
        
        <section>
            <br/>
            <br/>
            <br/>
            <section>KPMG(PTY)</section>
            <br/>
            <section>Microsoft SA &reg;</section>
            <br/>
            <section>Google SA &reg;</section>
            <br/>
            
        </section>
        <footer>
            <h4>Follow Us</h4>
        <p>|Facebook|</p>
        <p>Instagram|</p>
        <p>Google+|</p>
        <p>WeChat|</p>
        <p>Twitter</p>
      
        <p>Contact Us</p>
        <p>About Us</p>
        <p>FAQ</p>
        <p>All Right Reserved</p>
        <p>T&C's</p>
        <p>&reg;</p>
        <p>&copy;</p>
        
        
        </footer>
         
            
            
        </form>
        <?php
          if(isset($_POST['btnHelp']))
        {   
            header('Location:HelpPage.php');
        }
        
        if(isset($_POST['btnClient']))
        {
            header('Location:EmployeeMain.php');
        }
        if(isset($_POST['btnCompany']))
        {   
            header('Location:CompanyMain.php');
        }
        
        if(isset($_POST['btnCompanies']))
        {   
            header('Location:ShowAllCompanies.php');
        }
        
        ?>
    </body>
</html>
