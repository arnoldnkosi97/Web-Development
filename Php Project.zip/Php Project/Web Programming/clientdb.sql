-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2017 at 04:21 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clientdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `CompanyKey` int(11) NOT NULL,
  `CompanyName` varchar(25) NOT NULL,
  `Province` varchar(25) NOT NULL,
  `Industry` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`CompanyKey`, `CompanyName`, `Province`, `Industry`) VALUES
(1, 'MicroSoft', 'Gauteng', 'Information Technology'),
(2, 'Google', 'Cape Town', 'Information Technology'),
(3, 'Bhp Billiton', 'Mpumalanga', 'Mining');

-- --------------------------------------------------------

--
-- Table structure for table `cv`
--

CREATE TABLE `cv` (
  `EmployeeForeignKey` int(11) NOT NULL,
  `FirstName` varchar(25) NOT NULL,
  `MiddleName` varchar(25) NOT NULL,
  `Surname` varchar(25) NOT NULL,
  `Location` varchar(30) NOT NULL,
  `Nationality` varchar(25) NOT NULL,
  `EmailAddress` varchar(25) NOT NULL,
  `Availability` varchar(3) NOT NULL,
  `CurrentSalary` varchar(10) NOT NULL,
  `ExpectedSalary` varchar(10) NOT NULL,
  `Qualifications` varchar(50) NOT NULL,
  `Institution` varchar(25) NOT NULL,
  `YearMonthCompleted` date NOT NULL,
  `Courses` varchar(30) NOT NULL,
  `JobTitle` varchar(15) NOT NULL,
  `NameEmployer` varchar(15) NOT NULL,
  `PeriodEmployed` date NOT NULL,
  `SalaryPaid` varchar(10) NOT NULL,
  `Duties` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EmployeeKey` int(11) NOT NULL,
  `Title` varchar(10) NOT NULL,
  `FirstName` varchar(25) NOT NULL,
  `Surname` varchar(25) NOT NULL,
  `Nationality` varchar(15) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `IdNumber` int(13) NOT NULL,
  `Cv` text NOT NULL,
  `Id` text NOT NULL,
  `PreferredField` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EmployeeKey`, `Title`, `FirstName`, `Surname`, `Nationality`, `Gender`, `Address`, `IdNumber`, `Cv`, `Id`, `PreferredField`) VALUES
(1, 'mr', 'Arnold', 'Nkosi', 'Yes', 'Male', 'Silverton', 1313253241, '124124', 'agjabnsgasfav', '');

-- --------------------------------------------------------

--
-- Table structure for table `loginaccounts`
--

CREATE TABLE `loginaccounts` (
  `ForeignKey` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loginaccounts`
--

INSERT INTO `loginaccounts` (`ForeignKey`, `Username`, `Password`) VALUES
(1, 'arnold', 'nkosi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`CompanyKey`);

--
-- Indexes for table `cv`
--
ALTER TABLE `cv`
  ADD UNIQUE KEY `ForeignKey` (`EmployeeForeignKey`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EmployeeKey`);

--
-- Indexes for table `loginaccounts`
--
ALTER TABLE `loginaccounts`
  ADD UNIQUE KEY `ForeignKey` (`ForeignKey`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `CompanyKey` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `EmployeeKey` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
